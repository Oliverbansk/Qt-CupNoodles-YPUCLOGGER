#ifndef MYLOGININPUT_H
#define MYLOGININPUT_H


#include <QWidget>


namespace Ui {
class MyLoginInput;
}

class MyLoginInput : public QWidget
{
    Q_OBJECT

public:
    explicit MyLoginInput(QWidget *parent = 0);
    ~MyLoginInput();

signals:
    void showLogin();

private slots:
    void on_returnButton_clicked();
    void receiveLogin();

private:
    Ui::MyLoginInput *ui;
};

#endif // MYLOGININPUT_H
