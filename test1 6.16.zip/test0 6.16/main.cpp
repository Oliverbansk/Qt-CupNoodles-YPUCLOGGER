#include "mylogin.h"
#include "mylogininput.h"
#include "mypublicspace.h"
#include <QApplication>
#include <string>
#include <vector>
#include <queue>

class Qcomment{
public:
    string critic;
    double score;
    string comment;
};

class Qmovie{
public:
    string poster;//路径后缀
    string moviename;
    double ypuc_score;
    double db_score;
    string year;
    string director;
    string region;
    string introduction;
    vector<Qcomment> comment_list;
    void calculate_score(){
        int num = comment_list.size();
        double sum = 0;
        for(int i=0;i<num;i++){
            sum += comment_list[i].score;
        }
        ypuc_score = sum/num;
    }
};

class Quser{
public:
    string account;
    string password;
    string username;
    string realname;
    string grade;
    string major;
    string birthday;
    vector<Qmovie> movie_list;
    vector<Qmovie> top_five;

};

vector<Quser> all_users;
vector<Qmovie> all_movies;
queue<Qmovie> movies_displayed;//3个
queue<Qmovie> movies_to_display;//3个

void display()
{
    Qmovie tmp = movies_to_display.front();
    movies_to_display.pop();
    movies_displayed.push(tmp);
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MyLogin LoginWid;
    MyLoginInput loginInputWid;
    MyPublicSpace publicSpaceWid;
    publicSpaceWid.show();
    LoginWid.show();

    QObject::connect(&LoginWid,SIGNAL(showLoginInput()),&loginInputWid,SLOT(receiveLogin()));
    QObject::connect(&loginInputWid,SIGNAL(showLogin()),&LoginWid,SLOT(receiveLoginInput()));


    return a.exec();
}
