#ifndef MYPUBLICSPACE_H
#define MYPUBLICSPACE_H

#include <QWidget>

namespace Ui {
class MyPublicSpace;
}

class MyPublicSpace : public QWidget
{
    Q_OBJECT

public:
    explicit MyPublicSpace(QWidget *parent = 0);
    ~MyPublicSpace();

private:
    Ui::MyPublicSpace *ui;
};

#endif // MYPUBLICSPACE_H
