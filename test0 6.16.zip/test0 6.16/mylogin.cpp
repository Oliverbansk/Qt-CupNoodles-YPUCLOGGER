#include "mylogin.h"
#include "ui_mylogin.h"

MyLogin::MyLogin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MyLogin)
{
    ui->setupUi(this);
    ui->frame_login->setStyleSheet("#frame_login{border-image: url(:/loginbackground/loginbackground.jpg);}");

}

MyLogin::~MyLogin()
{
    delete ui;
}



void MyLogin::on_btUser_clicked()
{
    this->hide();
    emit showLoginInput();
}
void MyLogin::receiveLoginInput()
{
    this->show();
}





