#include "mylogininput.h"
#include "ui_mylogininput.h"

MyLoginInput::MyLoginInput(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MyLoginInput)
{
    ui->setupUi(this);
    ui->frame_logininput->setStyleSheet("#frame_logininput{border-image: url(:/loginbackground/logininputbackground.jpg);}");
}



MyLoginInput::~MyLoginInput()
{
    delete ui;
}

void MyLoginInput::on_returnButton_clicked()
{
    this->hide();
    emit showLogin();
}
void MyLoginInput::receiveLogin()
{
    this->show();
}





