/********************************************************************************
** Form generated from reading UI file 'mylogin.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MYLOGIN_H
#define UI_MYLOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MyLogin
{
public:
    QVBoxLayout *verticalLayout;
    QFrame *frame_login;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_4;
    QHBoxLayout *horizontalLayout;
    QLabel *label_up;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_left;
    QPushButton *btAdmin;
    QPushButton *btUser;
    QPushButton *btVisitor;
    QLabel *label_right;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_down;
    QHBoxLayout *horizontalLayout_5;

    void setupUi(QWidget *MyLogin)
    {
        if (MyLogin->objectName().isEmpty())
            MyLogin->setObjectName(QStringLiteral("MyLogin"));
        MyLogin->resize(900, 600);
        MyLogin->setStyleSheet(QStringLiteral(""));
        verticalLayout = new QVBoxLayout(MyLogin);
        verticalLayout->setSpacing(0);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(3, 3, 3, 3);
        frame_login = new QFrame(MyLogin);
        frame_login->setObjectName(QStringLiteral("frame_login"));
        frame_login->setFrameShape(QFrame::StyledPanel);
        frame_login->setFrameShadow(QFrame::Raised);
        verticalLayout_2 = new QVBoxLayout(frame_login);
        verticalLayout_2->setSpacing(0);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(0);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));

        verticalLayout_2->addLayout(horizontalLayout_4);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(0);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label_up = new QLabel(frame_login);
        label_up->setObjectName(QStringLiteral("label_up"));
        QSizePolicy sizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label_up->sizePolicy().hasHeightForWidth());
        label_up->setSizePolicy(sizePolicy);
        label_up->setStyleSheet(QString::fromUtf8("font: 87 15pt \"\346\200\235\346\272\220\345\256\213\344\275\223 CN Heavy\";\n"
"background-color: rgba(255, 255, 255, 150);"));

        horizontalLayout->addWidget(label_up, 0, Qt::AlignVCenter);


        verticalLayout_2->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_left = new QLabel(frame_login);
        label_left->setObjectName(QStringLiteral("label_left"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label_left->sizePolicy().hasHeightForWidth());
        label_left->setSizePolicy(sizePolicy1);
        label_left->setStyleSheet(QStringLiteral("background:transparent"));

        horizontalLayout_2->addWidget(label_left);

        btAdmin = new QPushButton(frame_login);
        btAdmin->setObjectName(QStringLiteral("btAdmin"));
        sizePolicy1.setHeightForWidth(btAdmin->sizePolicy().hasHeightForWidth());
        btAdmin->setSizePolicy(sizePolicy1);
        btAdmin->setStyleSheet(QString::fromUtf8("font: 87 14pt \"\346\200\235\346\272\220\345\256\213\344\275\223 CN Heavy\";\n"
"background-color: rgba(255, 255, 255, 150);\n"
"border-color: transparent"));
        btAdmin->setFlat(false);

        horizontalLayout_2->addWidget(btAdmin);

        btUser = new QPushButton(frame_login);
        btUser->setObjectName(QStringLiteral("btUser"));
        sizePolicy1.setHeightForWidth(btUser->sizePolicy().hasHeightForWidth());
        btUser->setSizePolicy(sizePolicy1);
        btUser->setStyleSheet(QString::fromUtf8("font: 87 14pt \"\346\200\235\346\272\220\345\256\213\344\275\223 CN Heavy\";\n"
"background-color: rgba(255, 255, 255, 150);\n"
"border-color: transparent"));
        btUser->setFlat(false);

        horizontalLayout_2->addWidget(btUser);

        btVisitor = new QPushButton(frame_login);
        btVisitor->setObjectName(QStringLiteral("btVisitor"));
        sizePolicy1.setHeightForWidth(btVisitor->sizePolicy().hasHeightForWidth());
        btVisitor->setSizePolicy(sizePolicy1);
        btVisitor->setStyleSheet(QString::fromUtf8("font: 87 14pt \"\346\200\235\346\272\220\345\256\213\344\275\223 CN Heavy\";\n"
"background-color: rgba(255, 255, 255, 150);\n"
"border-color: transparent"));
        btVisitor->setFlat(false);

        horizontalLayout_2->addWidget(btVisitor);

        label_right = new QLabel(frame_login);
        label_right->setObjectName(QStringLiteral("label_right"));
        sizePolicy1.setHeightForWidth(label_right->sizePolicy().hasHeightForWidth());
        label_right->setSizePolicy(sizePolicy1);
        label_right->setStyleSheet(QLatin1String("background:transparent\n"
""));

        horizontalLayout_2->addWidget(label_right);

        horizontalLayout_2->setStretch(0, 1);
        horizontalLayout_2->setStretch(1, 1);
        horizontalLayout_2->setStretch(2, 1);
        horizontalLayout_2->setStretch(3, 1);
        horizontalLayout_2->setStretch(4, 1);

        verticalLayout_2->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(0);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        label_down = new QLabel(frame_login);
        label_down->setObjectName(QStringLiteral("label_down"));
        sizePolicy.setHeightForWidth(label_down->sizePolicy().hasHeightForWidth());
        label_down->setSizePolicy(sizePolicy);
        label_down->setStyleSheet(QString::fromUtf8("font: 10pt \"\345\226\234\351\271\212\345\217\244\351\243\216\345\260\217\346\245\267\347\256\200\344\275\223\347\211\210 regular\";\n"
"background-color: rgba(255, 255, 255, 150);"));

        horizontalLayout_3->addWidget(label_down, 0, Qt::AlignVCenter);


        verticalLayout_2->addLayout(horizontalLayout_3);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(0);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));

        verticalLayout_2->addLayout(horizontalLayout_5);

        verticalLayout_2->setStretch(0, 10);
        verticalLayout_2->setStretch(1, 100);
        verticalLayout_2->setStretch(2, 70);
        verticalLayout_2->setStretch(3, 100);
        verticalLayout_2->setStretch(4, 10);
        label_up->raise();

        verticalLayout->addWidget(frame_login);


        retranslateUi(MyLogin);

        btAdmin->setDefault(false);


        QMetaObject::connectSlotsByName(MyLogin);
    } // setupUi

    void retranslateUi(QWidget *MyLogin)
    {
        MyLogin->setWindowTitle(QApplication::translate("MyLogin", "MyLogin", 0));
        label_up->setText(QApplication::translate("MyLogin", "<html><head/><body><p align=\"center\">\345\205\203\345\237\271\345\234\260\344\270\213\347\224\265\345\275\261\351\231\242\346\227\245\350\256\260\346\234\254</p><p align=\"center\">YPUC LOGGER</p></body></html>", 0));
        label_left->setText(QString());
        btAdmin->setText(QApplication::translate("MyLogin", "\347\256\241\347\220\206\345\221\230\347\231\273\345\275\225", 0));
        btUser->setText(QApplication::translate("MyLogin", "\347\224\250\346\210\267\347\231\273\345\275\225", 0));
        btVisitor->setText(QApplication::translate("MyLogin", "\346\270\270\345\256\242\347\231\273\345\275\225", 0));
        label_right->setText(QString());
        label_down->setText(QApplication::translate("MyLogin", "<html><head/><body><p align=\"center\"><span style=\" font-size:20pt;\">\346\265\267\346\213\224\347\272\246\347\255\211\344\272\216\346\234\252\345\220\215\346\271\226\345\272\225\342\200\246\342\200\246</span></p></body></html>", 0));
    } // retranslateUi

};

namespace Ui {
    class MyLogin: public Ui_MyLogin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MYLOGIN_H
