#ifndef MYLOGIN_H
#define MYLOGIN_H


#include <QWidget>
#include "mylogininput.h"

namespace Ui {
class MyLogin;
}

class MyLogin : public QWidget
{
    Q_OBJECT

public:
    explicit MyLogin(QWidget *parent = 0);
    ~MyLogin();

signals:
    void showLoginInput();

private slots:
    void receiveLoginInput();
    void on_btUser_clicked();

private:
    Ui::MyLogin *ui;
    MyLoginInput loginInputWid;
};

#endif // MYLOGIN_H
