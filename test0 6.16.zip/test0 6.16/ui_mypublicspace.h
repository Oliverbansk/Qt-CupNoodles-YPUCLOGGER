/********************************************************************************
** Form generated from reading UI file 'mypublicspace.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MYPUBLICSPACE_H
#define UI_MYPUBLICSPACE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MyPublicSpace
{
public:
    QHBoxLayout *horizontalLayout_15;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_2;
    QLabel *recent;
    QLabel *label;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_9;
    QWidget *recentMovie1;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_16;
    QLabel *label_15;
    QWidget *widget;
    QVBoxLayout *verticalLayout_6;
    QHBoxLayout *horizontalLayout_19;
    QLabel *label_16;
    QToolButton *toolButton_2;
    QHBoxLayout *horizontalLayout_20;
    QLabel *label_4;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_6;
    QWidget *recentMovie2;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_13;
    QLabel *label_14;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *horizontalLayout_17;
    QLabel *label_17;
    QToolButton *toolButton;
    QHBoxLayout *horizontalLayout_18;
    QLabel *label_10;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_7;
    QLabel *label_11;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_12;
    QLabel *label_8;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *pushButton;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_10;
    QLabel *label_5;
    QLabel *future;
    QLabel *label_3;
    QHBoxLayout *horizontalLayout_14;
    QHBoxLayout *horizontalLayout_13;
    QHBoxLayout *horizontalLayout_12;
    QHBoxLayout *horizontalLayout_11;
    QHBoxLayout *horizontalLayout_8;

    void setupUi(QWidget *MyPublicSpace)
    {
        if (MyPublicSpace->objectName().isEmpty())
            MyPublicSpace->setObjectName(QStringLiteral("MyPublicSpace"));
        MyPublicSpace->resize(900, 600);
        horizontalLayout_15 = new QHBoxLayout(MyPublicSpace);
        horizontalLayout_15->setObjectName(QStringLiteral("horizontalLayout_15"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(2);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        label_2 = new QLabel(MyPublicSpace);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout_3->addWidget(label_2);

        recent = new QLabel(MyPublicSpace);
        recent->setObjectName(QStringLiteral("recent"));

        horizontalLayout_3->addWidget(recent);

        label = new QLabel(MyPublicSpace);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout_3->addWidget(label);

        horizontalLayout_3->setStretch(0, 2);
        horizontalLayout_3->setStretch(1, 5);
        horizontalLayout_3->setStretch(2, 2);

        verticalLayout_4->addLayout(horizontalLayout_3);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        label_9 = new QLabel(MyPublicSpace);
        label_9->setObjectName(QStringLiteral("label_9"));

        horizontalLayout_5->addWidget(label_9);

        recentMovie1 = new QWidget(MyPublicSpace);
        recentMovie1->setObjectName(QStringLiteral("recentMovie1"));
        verticalLayout_2 = new QVBoxLayout(recentMovie1);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setObjectName(QStringLiteral("horizontalLayout_16"));
        label_15 = new QLabel(recentMovie1);
        label_15->setObjectName(QStringLiteral("label_15"));

        horizontalLayout_16->addWidget(label_15);

        widget = new QWidget(recentMovie1);
        widget->setObjectName(QStringLiteral("widget"));

        horizontalLayout_16->addWidget(widget);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(0);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setObjectName(QStringLiteral("horizontalLayout_19"));
        label_16 = new QLabel(recentMovie1);
        label_16->setObjectName(QStringLiteral("label_16"));

        horizontalLayout_19->addWidget(label_16);

        toolButton_2 = new QToolButton(recentMovie1);
        toolButton_2->setObjectName(QStringLiteral("toolButton_2"));
        toolButton_2->setArrowType(Qt::DownArrow);

        horizontalLayout_19->addWidget(toolButton_2);

        horizontalLayout_19->setStretch(0, 5);
        horizontalLayout_19->setStretch(1, 1);

        verticalLayout_6->addLayout(horizontalLayout_19);

        horizontalLayout_20 = new QHBoxLayout();
        horizontalLayout_20->setObjectName(QStringLiteral("horizontalLayout_20"));

        verticalLayout_6->addLayout(horizontalLayout_20);

        verticalLayout_6->setStretch(0, 1);
        verticalLayout_6->setStretch(1, 5);

        horizontalLayout_16->addLayout(verticalLayout_6);

        horizontalLayout_16->setStretch(0, 2);
        horizontalLayout_16->setStretch(1, 3);
        horizontalLayout_16->setStretch(2, 3);

        verticalLayout_2->addLayout(horizontalLayout_16);


        horizontalLayout_5->addWidget(recentMovie1);

        label_4 = new QLabel(MyPublicSpace);
        label_4->setObjectName(QStringLiteral("label_4"));

        horizontalLayout_5->addWidget(label_4);

        horizontalLayout_5->setStretch(0, 1);
        horizontalLayout_5->setStretch(1, 6);
        horizontalLayout_5->setStretch(2, 1);

        verticalLayout_4->addLayout(horizontalLayout_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        label_6 = new QLabel(MyPublicSpace);
        label_6->setObjectName(QStringLiteral("label_6"));

        horizontalLayout_6->addWidget(label_6);

        recentMovie2 = new QWidget(MyPublicSpace);
        recentMovie2->setObjectName(QStringLiteral("recentMovie2"));
        verticalLayout = new QVBoxLayout(recentMovie2);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(2);
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        label_13 = new QLabel(recentMovie2);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setStyleSheet(QStringLiteral(""));

        horizontalLayout_9->addWidget(label_13);

        label_14 = new QLabel(recentMovie2);
        label_14->setObjectName(QStringLiteral("label_14"));

        horizontalLayout_9->addWidget(label_14);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(0);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setObjectName(QStringLiteral("horizontalLayout_17"));
        label_17 = new QLabel(recentMovie2);
        label_17->setObjectName(QStringLiteral("label_17"));

        horizontalLayout_17->addWidget(label_17);

        toolButton = new QToolButton(recentMovie2);
        toolButton->setObjectName(QStringLiteral("toolButton"));
        toolButton->setEnabled(true);
        QSizePolicy sizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(toolButton->sizePolicy().hasHeightForWidth());
        toolButton->setSizePolicy(sizePolicy);
        toolButton->setPopupMode(QToolButton::DelayedPopup);
        toolButton->setToolButtonStyle(Qt::ToolButtonIconOnly);
        toolButton->setArrowType(Qt::DownArrow);

        horizontalLayout_17->addWidget(toolButton, 0, Qt::AlignHCenter);

        horizontalLayout_17->setStretch(0, 5);
        horizontalLayout_17->setStretch(1, 1);

        verticalLayout_5->addLayout(horizontalLayout_17);

        horizontalLayout_18 = new QHBoxLayout();
        horizontalLayout_18->setSpacing(0);
        horizontalLayout_18->setObjectName(QStringLiteral("horizontalLayout_18"));

        verticalLayout_5->addLayout(horizontalLayout_18);

        verticalLayout_5->setStretch(0, 1);
        verticalLayout_5->setStretch(1, 5);

        horizontalLayout_9->addLayout(verticalLayout_5);

        horizontalLayout_9->setStretch(0, 2);
        horizontalLayout_9->setStretch(1, 3);
        horizontalLayout_9->setStretch(2, 3);

        verticalLayout->addLayout(horizontalLayout_9);


        horizontalLayout_6->addWidget(recentMovie2);

        label_10 = new QLabel(MyPublicSpace);
        label_10->setObjectName(QStringLiteral("label_10"));

        horizontalLayout_6->addWidget(label_10);

        horizontalLayout_6->setStretch(0, 1);
        horizontalLayout_6->setStretch(1, 6);
        horizontalLayout_6->setStretch(2, 1);

        verticalLayout_4->addLayout(horizontalLayout_6);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        label_7 = new QLabel(MyPublicSpace);
        label_7->setObjectName(QStringLiteral("label_7"));

        horizontalLayout_7->addWidget(label_7);

        label_11 = new QLabel(MyPublicSpace);
        label_11->setObjectName(QStringLiteral("label_11"));

        horizontalLayout_7->addWidget(label_11);

        horizontalLayout_7->setStretch(0, 1);
        horizontalLayout_7->setStretch(1, 1);

        verticalLayout_4->addLayout(horizontalLayout_7);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        label_12 = new QLabel(MyPublicSpace);
        label_12->setObjectName(QStringLiteral("label_12"));

        horizontalLayout_4->addWidget(label_12);

        label_8 = new QLabel(MyPublicSpace);
        label_8->setObjectName(QStringLiteral("label_8"));

        horizontalLayout_4->addWidget(label_8);

        horizontalLayout_4->setStretch(0, 1);
        horizontalLayout_4->setStretch(1, 1);

        verticalLayout_4->addLayout(horizontalLayout_4);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        pushButton = new QPushButton(MyPublicSpace);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));

        horizontalLayout_2->addWidget(pushButton);


        verticalLayout_4->addLayout(horizontalLayout_2);

        verticalLayout_4->setStretch(0, 4);
        verticalLayout_4->setStretch(1, 5);
        verticalLayout_4->setStretch(2, 5);
        verticalLayout_4->setStretch(3, 5);
        verticalLayout_4->setStretch(4, 5);
        verticalLayout_4->setStretch(5, 4);

        horizontalLayout->addLayout(verticalLayout_4);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        label_5 = new QLabel(MyPublicSpace);
        label_5->setObjectName(QStringLiteral("label_5"));

        horizontalLayout_10->addWidget(label_5);

        future = new QLabel(MyPublicSpace);
        future->setObjectName(QStringLiteral("future"));

        horizontalLayout_10->addWidget(future);

        label_3 = new QLabel(MyPublicSpace);
        label_3->setObjectName(QStringLiteral("label_3"));

        horizontalLayout_10->addWidget(label_3);

        horizontalLayout_10->setStretch(0, 2);
        horizontalLayout_10->setStretch(1, 5);
        horizontalLayout_10->setStretch(2, 2);

        verticalLayout_3->addLayout(horizontalLayout_10);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));

        verticalLayout_3->addLayout(horizontalLayout_14);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));

        verticalLayout_3->addLayout(horizontalLayout_13);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));

        verticalLayout_3->addLayout(horizontalLayout_12);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));

        verticalLayout_3->addLayout(horizontalLayout_11);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));

        verticalLayout_3->addLayout(horizontalLayout_8);

        verticalLayout_3->setStretch(0, 5);
        verticalLayout_3->setStretch(1, 5);
        verticalLayout_3->setStretch(2, 5);
        verticalLayout_3->setStretch(3, 5);
        verticalLayout_3->setStretch(4, 5);
        verticalLayout_3->setStretch(5, 4);

        horizontalLayout->addLayout(verticalLayout_3);

        horizontalLayout->setStretch(0, 1);
        horizontalLayout->setStretch(1, 1);

        horizontalLayout_15->addLayout(horizontalLayout);


        retranslateUi(MyPublicSpace);

        QMetaObject::connectSlotsByName(MyPublicSpace);
    } // setupUi

    void retranslateUi(QWidget *MyPublicSpace)
    {
        MyPublicSpace->setWindowTitle(QApplication::translate("MyPublicSpace", "Form", 0));
        label_2->setText(QString());
        recent->setText(QApplication::translate("MyPublicSpace", "<html><head/><body><p><span style=\" font-size:11pt;\">\346\234\200\350\277\221\344\270\203\345\244\251</span></p></body></html>", 0));
        label->setText(QString());
        label_9->setText(QString());
        label_15->setText(QApplication::translate("MyPublicSpace", "\347\224\265\345\275\261\345\233\276\347\211\207", 0));
        label_16->setText(QString());
        toolButton_2->setText(QApplication::translate("MyPublicSpace", "...", 0));
        label_4->setText(QString());
        label_6->setText(QString());
        label_13->setText(QApplication::translate("MyPublicSpace", "<html><head/><body><p>\347\224\265\345\275\261\345\233\276\347\211\207</p></body></html>", 0));
        label_14->setText(QApplication::translate("MyPublicSpace", "\346\265\252\346\275\256", 0));
        label_17->setText(QString());
        toolButton->setText(QString());
        label_10->setText(QString());
        label_7->setText(QString());
        label_11->setText(QString());
        label_12->setText(QString());
        label_8->setText(QString());
        pushButton->setText(QApplication::translate("MyPublicSpace", "PushButton", 0));
        label_5->setText(QString());
        future->setText(QApplication::translate("MyPublicSpace", "<html><head/><body><p><span style=\" font-size:11pt;\">\346\234\252\346\235\245\344\270\203\345\244\251</span></p></body></html>", 0));
        label_3->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MyPublicSpace: public Ui_MyPublicSpace {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MYPUBLICSPACE_H
