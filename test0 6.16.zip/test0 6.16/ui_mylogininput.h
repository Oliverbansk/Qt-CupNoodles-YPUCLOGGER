/********************************************************************************
** Form generated from reading UI file 'mylogininput.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MYLOGININPUT_H
#define UI_MYLOGININPUT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MyLoginInput
{
public:
    QVBoxLayout *verticalLayout;
    QFrame *frame_logininput;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_6;
    QToolButton *returnButton;
    QLabel *blank5;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_up;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_4;
    QLabel *blank1;
    QLabel *lbUsername;
    QLineEdit *lineEdit_username;
    QLabel *blank2;
    QHBoxLayout *horizontalLayout_5;
    QLabel *blank3;
    QLabel *lbCode;
    QLineEdit *lineEdit_code;
    QLabel *blank4;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_down;
    QVBoxLayout *verticalLayout_4;

    void setupUi(QWidget *MyLoginInput)
    {
        if (MyLoginInput->objectName().isEmpty())
            MyLoginInput->setObjectName(QStringLiteral("MyLoginInput"));
        MyLoginInput->resize(900, 600);
        verticalLayout = new QVBoxLayout(MyLoginInput);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        frame_logininput = new QFrame(MyLoginInput);
        frame_logininput->setObjectName(QStringLiteral("frame_logininput"));
        frame_logininput->setStyleSheet(QStringLiteral(""));
        frame_logininput->setFrameShape(QFrame::StyledPanel);
        frame_logininput->setFrameShadow(QFrame::Raised);
        verticalLayout_3 = new QVBoxLayout(frame_logininput);
        verticalLayout_3->setSpacing(0);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        returnButton = new QToolButton(frame_logininput);
        returnButton->setObjectName(QStringLiteral("returnButton"));
        returnButton->setEnabled(true);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(returnButton->sizePolicy().hasHeightForWidth());
        returnButton->setSizePolicy(sizePolicy);
        returnButton->setLayoutDirection(Qt::LeftToRight);
        returnButton->setStyleSheet(QStringLiteral("background-color:rgba(255, 255, 255, 150)"));
        returnButton->setArrowType(Qt::LeftArrow);

        horizontalLayout_6->addWidget(returnButton, 0, Qt::AlignLeft);

        blank5 = new QLabel(frame_logininput);
        blank5->setObjectName(QStringLiteral("blank5"));

        horizontalLayout_6->addWidget(blank5);

        horizontalLayout_6->setStretch(0, 1);
        horizontalLayout_6->setStretch(1, 20);

        verticalLayout_3->addLayout(horizontalLayout_6);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        label_up = new QLabel(frame_logininput);
        label_up->setObjectName(QStringLiteral("label_up"));
        QSizePolicy sizePolicy1(QSizePolicy::Ignored, QSizePolicy::Ignored);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label_up->sizePolicy().hasHeightForWidth());
        label_up->setSizePolicy(sizePolicy1);
        label_up->setStyleSheet(QString::fromUtf8("font: 87 15pt \"\346\200\235\346\272\220\345\256\213\344\275\223 CN Heavy\";\n"
"background-color: rgba(255, 255, 255, 175);"));

        horizontalLayout_2->addWidget(label_up, 0, Qt::AlignVCenter);


        verticalLayout_3->addLayout(horizontalLayout_2);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(3);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(5);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        blank1 = new QLabel(frame_logininput);
        blank1->setObjectName(QStringLiteral("blank1"));

        horizontalLayout_4->addWidget(blank1);

        lbUsername = new QLabel(frame_logininput);
        lbUsername->setObjectName(QStringLiteral("lbUsername"));
        lbUsername->setStyleSheet(QString::fromUtf8("font: 87 12pt \"\346\200\235\346\272\220\345\256\213\344\275\223 CN Heavy\";\n"
"background-color: rgba(255, 255, 255, 150);"));

        horizontalLayout_4->addWidget(lbUsername, 0, Qt::AlignVCenter);

        lineEdit_username = new QLineEdit(frame_logininput);
        lineEdit_username->setObjectName(QStringLiteral("lineEdit_username"));
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(lineEdit_username->sizePolicy().hasHeightForWidth());
        lineEdit_username->setSizePolicy(sizePolicy2);
        lineEdit_username->setStyleSheet(QLatin1String("border-color: rgb(0, 0, 0);\n"
"background-color: rgba(255, 255, 255, 210);"));
        lineEdit_username->setFrame(true);
        lineEdit_username->setEchoMode(QLineEdit::Normal);
        lineEdit_username->setCursorPosition(0);
        lineEdit_username->setDragEnabled(false);
        lineEdit_username->setReadOnly(false);
        lineEdit_username->setClearButtonEnabled(false);

        horizontalLayout_4->addWidget(lineEdit_username, 0, Qt::AlignVCenter);

        blank2 = new QLabel(frame_logininput);
        blank2->setObjectName(QStringLiteral("blank2"));

        horizontalLayout_4->addWidget(blank2);

        horizontalLayout_4->setStretch(0, 2);
        horizontalLayout_4->setStretch(1, 1);
        horizontalLayout_4->setStretch(2, 7);
        horizontalLayout_4->setStretch(3, 2);

        verticalLayout_2->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(5);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        blank3 = new QLabel(frame_logininput);
        blank3->setObjectName(QStringLiteral("blank3"));

        horizontalLayout_5->addWidget(blank3);

        lbCode = new QLabel(frame_logininput);
        lbCode->setObjectName(QStringLiteral("lbCode"));
        lbCode->setStyleSheet(QString::fromUtf8("font: 87 12pt \"\346\200\235\346\272\220\345\256\213\344\275\223 CN Heavy\";\n"
"background-color: rgba(255, 255, 255, 150);"));

        horizontalLayout_5->addWidget(lbCode, 0, Qt::AlignVCenter);

        lineEdit_code = new QLineEdit(frame_logininput);
        lineEdit_code->setObjectName(QStringLiteral("lineEdit_code"));
        sizePolicy2.setHeightForWidth(lineEdit_code->sizePolicy().hasHeightForWidth());
        lineEdit_code->setSizePolicy(sizePolicy2);
        lineEdit_code->setStyleSheet(QLatin1String("border-color: rgb(0, 0, 0);\n"
"background-color: rgba(255, 255, 255, 210);\n"
""));
        lineEdit_code->setFrame(true);
        lineEdit_code->setEchoMode(QLineEdit::Password);

        horizontalLayout_5->addWidget(lineEdit_code, 0, Qt::AlignVCenter);

        blank4 = new QLabel(frame_logininput);
        blank4->setObjectName(QStringLiteral("blank4"));

        horizontalLayout_5->addWidget(blank4);

        horizontalLayout_5->setStretch(0, 2);
        horizontalLayout_5->setStretch(1, 1);
        horizontalLayout_5->setStretch(2, 7);
        horizontalLayout_5->setStretch(3, 2);

        verticalLayout_2->addLayout(horizontalLayout_5);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        pushButton = new QPushButton(frame_logininput);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        sizePolicy2.setHeightForWidth(pushButton->sizePolicy().hasHeightForWidth());
        pushButton->setSizePolicy(sizePolicy2);
        pushButton->setMinimumSize(QSize(0, 15));

        horizontalLayout->addWidget(pushButton, 0, Qt::AlignHCenter|Qt::AlignVCenter);


        verticalLayout_2->addLayout(horizontalLayout);

        verticalLayout_2->setStretch(0, 5);
        verticalLayout_2->setStretch(1, 5);
        verticalLayout_2->setStretch(2, 4);

        verticalLayout_3->addLayout(verticalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        label_down = new QLabel(frame_logininput);
        label_down->setObjectName(QStringLiteral("label_down"));
        sizePolicy1.setHeightForWidth(label_down->sizePolicy().hasHeightForWidth());
        label_down->setSizePolicy(sizePolicy1);
        label_down->setStyleSheet(QString::fromUtf8("font: 10pt \"\345\226\234\351\271\212\345\217\244\351\243\216\345\260\217\346\245\267\347\256\200\344\275\223\347\211\210 regular\";\n"
"background-color: rgba(255, 255, 255, 160);"));

        horizontalLayout_3->addWidget(label_down, 0, Qt::AlignVCenter);


        verticalLayout_3->addLayout(horizontalLayout_3);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));

        verticalLayout_3->addLayout(verticalLayout_4);

        verticalLayout_3->setStretch(0, 10);
        verticalLayout_3->setStretch(1, 100);
        verticalLayout_3->setStretch(2, 70);
        verticalLayout_3->setStretch(3, 100);
        verticalLayout_3->setStretch(4, 10);
        label_up->raise();
        label_up->raise();
        label_up->raise();

        verticalLayout->addWidget(frame_logininput);

        verticalLayout->setStretch(0, 250);

        retranslateUi(MyLoginInput);

        QMetaObject::connectSlotsByName(MyLoginInput);
    } // setupUi

    void retranslateUi(QWidget *MyLoginInput)
    {
        MyLoginInput->setWindowTitle(QApplication::translate("MyLoginInput", "Form", 0));
        returnButton->setText(QString());
        blank5->setText(QString());
        label_up->setText(QApplication::translate("MyLoginInput", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt;\">\345\205\203\345\237\271\345\234\260\344\270\213\347\224\265\345\275\261\351\231\242\346\227\245\350\256\260\346\234\254</span></p><p align=\"center\"><span style=\" font-size:16pt;\">YPUC LOGGER</span></p></body></html>", 0));
        blank1->setText(QString());
        lbUsername->setText(QApplication::translate("MyLoginInput", "<html><head/><body><p align=\"center\"> \347\224\250\346\210\267\345\220\215\357\274\232</p></body></html>", 0));
        blank2->setText(QString());
        blank3->setText(QString());
        lbCode->setText(QApplication::translate("MyLoginInput", "<html><head/><body><p align=\"center\"> \345\257\206\347\240\201\357\274\232</p></body></html>", 0));
        blank4->setText(QString());
        pushButton->setText(QApplication::translate("MyLoginInput", "\347\241\256\345\256\232", 0));
        label_down->setText(QApplication::translate("MyLoginInput", "<html><head/><body><p align=\"center\"><span style=\" font-size:20pt;\">\346\265\267\346\213\224\347\272\246\347\255\211\344\272\216\346\234\252\345\220\215\346\271\226\345\272\225\342\200\246\342\200\246</span></p></body></html>", 0));
    } // retranslateUi

};

namespace Ui {
    class MyLoginInput: public Ui_MyLoginInput {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MYLOGININPUT_H
