#include "mylogin.h"
#include "mylogininput.h"
#include "mypublicspace.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MyLogin LoginWid;
    MyLoginInput loginInputWid;
    MyPublicSpace publicSpaceWid;
    publicSpaceWid.show();
    LoginWid.show();

    QObject::connect(&LoginWid,SIGNAL(showLoginInput()),&loginInputWid,SLOT(receiveLogin()));
    QObject::connect(&loginInputWid,SIGNAL(showLogin()),&LoginWid,SLOT(receiveLoginInput()));


    return a.exec();
}
