#include "mypublicspace.h"
#include "ui_mypublicspace.h"

MyPublicSpace::MyPublicSpace(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MyPublicSpace)
{
    ui->setupUi(this);
}

MyPublicSpace::~MyPublicSpace()
{
    delete ui;
}
